#inclide <stdio.h>

void main() {
	int number;
	
	do {
		printf("Enter a number between 5 to 10");
		scanf("%d",&number);
	} while (number < 5 || number >10);
}
