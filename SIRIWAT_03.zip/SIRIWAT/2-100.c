#include <stdio.h>

int main() {
	int i = 2, sum;
	
	while (i <= 100) {
	    printf("%d + ",i);
	    sum = sum+i;
	    i+=2;
	}
	printf("=%d\n", sum);
}
