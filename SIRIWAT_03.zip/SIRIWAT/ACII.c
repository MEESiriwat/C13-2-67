#include <stdio.h>

int main() {
	char C;
	printf("Enter a charavter : ");
	scanf("%c", &C);
	
	//%d displays the integer value of a character
	//%c displays the actual character
	printf("ASCII value of %c = %d", C, C);
	
	return 0;
}
