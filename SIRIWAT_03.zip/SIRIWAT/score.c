#include <stdio.h>

void main() {
	int sum = 0, score;
	
	printf("Enter first score (or 99 to quit)>");
	scanf("%d", &score);
	
	while (score != 99) {
		sum = sum + score;
	}
	
	printf("\nSum of exam scores is %d\n", sum);
}
