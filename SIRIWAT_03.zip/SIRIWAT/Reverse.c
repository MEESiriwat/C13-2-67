#include <stdio.h>

void main() {
	int N, R;
	printf("Enter a number : ");
	scanf("%d", &N);
	
	do {
		R = N%10; printf("%d", R);
		N = N/10;
	} while (N != 0);
}
