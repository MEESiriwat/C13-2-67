#include <stdio.h>

int main() {
	char c;
	int i,num;
	
	do{
		printf("\nEnter number = ");
		scanf("%d", &num);
		
		for(i=1; i<=12; i++)
			printf("%d x %d = %d\n", num, i, num*i");
		
		printf("DO you want to continue?(Y/N) > ");
		scanf("%c", &c);
		
	} while (c=='Y' || c=='y');
}
