#include <stdio.h>

int main() {
	int LOW_MONTH = 1, HIGH_MONTH = 12;
	int month;
	
	printf("Enter birth month > ");
	scanf("%d", &month);
	
	while (month<LOW_MONTH || month > HIGH_MONTH) {
	    printf("Enter birth month > ");
	    scanf("%d", &month);
	}
	printf("\nYour birth month is %d\n", month);
}
