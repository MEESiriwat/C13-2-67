#include <stdio.h>

int main() {
	int i = 1, sum;
	
	while (i <= 100) {
	    printf("%d + ",i);
	    sum = sum+i;
	    i+=5;
	}
	printf("=%d\n", sum);
}
